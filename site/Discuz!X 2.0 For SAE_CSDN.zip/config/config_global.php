<?php

define('SAE_STORAGE_DOMAIN_NAME','discuzx');
define('SAE_STORAGE_DOMAIN','http://'.$_SERVER['HTTP_APPNAME'].'-'.SAE_STORAGE_DOMAIN_NAME.'.stor.sinaapp.com/');


$_config = array();

// ----------------------------  CONFIG DB  ----------------------------- //
$_config['db']['1']['dbhost'] = SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT;
$_config['db']['1']['dbuser'] = SAE_MYSQL_USER;
$_config['db']['1']['dbpw'] =  SAE_MYSQL_PASS;
$_config['db']['1']['dbcharset'] = 'utf8';
$_config['db']['1']['pconnect'] = '0';
$_config['db']['1']['dbname'] = SAE_MYSQL_DB;
$_config['db']['1']['tablepre'] = 'sae_';
$_config['db']['common']['slave_except_table'] = 'common_session';

$_config['db']['slave']['1']['dbhost'] = SAE_MYSQL_HOST_S.':'.SAE_MYSQL_PORT;
$_config['db']['slave']['1']['dbuser'] = SAE_MYSQL_USER;
$_config['db']['slave']['1']['dbpw'] = SAE_MYSQL_PASS;
$_config['db']['slave']['1']['dbcharset'] = 'utf8';
$_config['db']['slave']['1']['pconnect'] = '0';
$_config['db']['slave']['1']['dbname'] = SAE_MYSQL_DB;
$_config['db']['slave']['1']['tablepre'] = 'sae_';

// --------------------------  CONFIG MEMORY  --------------------------- //
$_config['memory']['prefix'] = '7tALQ2_';
$_config['memory']['eaccelerator'] = 0;
$_config['memory']['apc'] = 0;
$_config['memory']['xcache'] = 0;
$_config['memory']['memcache']['server'] = '127.0.0.1';
$_config['memory']['memcache']['port'] = 11211;
$_config['memory']['memcache']['pconnect'] = 1;
$_config['memory']['memcache']['timeout'] = 1;

// --------------------------  CONFIG SERVER  --------------------------- //
$_config['server']['id'] = 1;

// -------------------------  CONFIG DOWNLOAD  -------------------------- //
$_config['download']['readmod'] = 2;
$_config['download']['xsendfile']['type'] = '0';
$_config['download']['xsendfile']['dir'] = '/down/';

// ---------------------------  CONFIG CACHE  --------------------------- //
$_config['cache']['type'] = 'sql';

// --------------------------  CONFIG OUTPUT  --------------------------- //
$_config['output']['charset'] = 'utf-8';
$_config['output']['forceheader'] = 1;
$_config['output']['gzip'] = '0';
$_config['output']['tplrefresh'] = 1;
$_config['output']['language'] = 'zh_cn';
$_config['output']['staticurl'] = 'static/';
$_config['output']['ajaxvalidate'] = '0';
$_config['output']['iecompatible'] = '0';

// --------------------------  CONFIG COOKIE  --------------------------- //
$_config['cookie']['cookiepre'] = '1YZJ_';
$_config['cookie']['cookiedomain'] = '';
$_config['cookie']['cookiepath'] = '/';

// -------------------------  CONFIG SECURITY  -------------------------- //
$_config['security']['authkey'] = '2b05ecEhUngUSTNJ';
$_config['security']['urlxssdefend'] = 1;
$_config['security']['attackevasive'] = '0';
$_config['security']['querysafe']['status'] = 1;
$_config['security']['querysafe']['dfunction']['0'] = 'load_file';
$_config['security']['querysafe']['dfunction']['1'] = 'hex';
$_config['security']['querysafe']['dfunction']['2'] = 'substring';
$_config['security']['querysafe']['dfunction']['3'] = 'if';
$_config['security']['querysafe']['dfunction']['4'] = 'ord';
$_config['security']['querysafe']['dfunction']['5'] = 'char';
$_config['security']['querysafe']['daction']['0'] = 'intooutfile';
$_config['security']['querysafe']['daction']['1'] = 'intodumpfile';
$_config['security']['querysafe']['daction']['2'] = 'unionselect';
$_config['security']['querysafe']['daction']['3'] = '(select';
$_config['security']['querysafe']['dnote']['0'] = '/*';
$_config['security']['querysafe']['dnote']['1'] = '*/';
$_config['security']['querysafe']['dnote']['2'] = '#';
$_config['security']['querysafe']['dnote']['3'] = '--';
$_config['security']['querysafe']['dnote']['4'] = '"';
$_config['security']['querysafe']['dlikehex'] = 1;
$_config['security']['querysafe']['afullnote'] = 1;

// --------------------------  CONFIG ADMINCP  -------------------------- //
// -------- Founders: $_config['admincp']['founder'] = '1,2,3'; --------- //
$_config['admincp']['founder'] = '1';
$_config['admincp']['forcesecques'] = '0';
$_config['admincp']['checkip'] = 1;
$_config['admincp']['runquery'] = 1;
$_config['admincp']['dbimport'] = 1;

// --------------------------  CONFIG REMOTE  --------------------------- //
$_config['remote']['on'] = '0';
$_config['remote']['dir'] = 'remote';
$_config['remote']['appkey'] = '62cf0b3c3e6a4c9468e7216839721d8e';
$_config['remote']['cron'] = '0';


// -------------------  THE END  -------------------- //

?>