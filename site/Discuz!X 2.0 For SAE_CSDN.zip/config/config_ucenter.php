<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT);
define('UC_DBUSER', SAE_MYSQL_USER);
define('UC_DBPW', SAE_MYSQL_PASS);
define('UC_DBNAME', SAE_MYSQL_DB);
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`'.'app_'.$_SERVER['HTTP_APPNAME'].'`.sae_ucenter_');

define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'c7y9kfx0J2G70fMdUah4zaGdtcA7f089eesbs3P6M1F6p0bcvbqdMfS5MdG8Y0D9');
define('UC_API', 'http://'.$_SERVER['HTTP_APPNAME'].'.sinaapp.com/uc_server');
define('UC_APPID', '1');
define('UC_IP', '127.0.0.1');
define('UC_PPP', 20);
?>