<?PHP
exit;
print_r($_SERVER);
echo '<hr/>';
echo  SAE_ACCESSKEY;
echo '<hr/>';
echo SAE_SECRETKEY;