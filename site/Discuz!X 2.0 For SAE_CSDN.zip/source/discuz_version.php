<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: discuz_version.php 22918 2011-05-31 05:23:44Z cnteacher $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!defined('DISCUZ_VERSION')) {
	define('DISCUZ_VERSION', 'X2');
	define('DISCUZ_RELEASE', '20110531');
}

?>